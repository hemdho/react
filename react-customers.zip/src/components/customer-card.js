import React from 'react';
import { Card, Button, Icon } from 'semantic-ui-react'
import { Link } from 'react-router-dom';

export default function CustomerCard({customer, deleteCustomer}) {
  return (
    <Card>
      <Card.Content>
        <Card.Header>
          <Icon name='user outline'/> {customer.firstname} {customer.lastname}
        </Card.Header>
        <Card.Description>
          <p><Icon name='phone'/> {customer.mobile}</p>
          
          <p><Icon name='address book outline'/> {customer.street1} {customer.street2} {customer.city}, {customer.state} {customer.postcode}</p>
        </Card.Description>
      </Card.Content>
      <Card.Content extra>
        <div className="ui two buttons">
          <Link to={`/customers/edit/${customer.id}`} className="ui basic button green">Edit</Link>
          <Button basic color="red" onClick={() => deleteCustomer(customer.id)} >Delete</Button>
        </div>
      </Card.Content>
    </Card>
  )
}

CustomerCard.propTypes = {
  customer: React.PropTypes.object.isRequired
}
